package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// MainActivity : activité principale
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // On lie cette activité au layout activity_main.xml
        setContentView(R.layout.activity_main);

        // On récupère le bouton depuis le layout
        Button btnScan = (Button) findViewById(R.id.btnCheckWifi);

        // On définit ce qui se passe quand l'utilisateur clique sur le bouton
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // On affiche un petit message à l'écran
                Toast monToast = Toast.makeText(
                        MainActivity.this, // contexte : notre activité
                        "Bouton cliqué !",  // message affiché
                        Toast.LENGTH_SHORT   // durée
                );
                monToast.show(); // on montre le Toast
            }
        });
    }
}
