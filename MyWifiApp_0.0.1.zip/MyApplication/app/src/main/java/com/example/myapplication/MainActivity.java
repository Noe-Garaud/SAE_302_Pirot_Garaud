package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnScan = (Button) findViewById(R.id.btnCheckWifi);

        btnScan.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast monToast = Toast.makeText(
                        MainActivity.this,
                        "Bouton cliqué !",
                        Toast.LENGTH_SHORT
                );
                monToast.show();
            }
        });
    }
}

