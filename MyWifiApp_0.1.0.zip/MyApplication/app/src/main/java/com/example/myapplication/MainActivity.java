package com.example.myapplication;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    WifiManager wifiManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wifiManager = (WifiManager) getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);

        Button btnScan = (Button) findViewById(R.id.btnCheckWifi);

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!wifiManager.isWifiEnabled()) {
                    wifiManager.setWifiEnabled(true);

                    Toast.makeText(
                            MainActivity.this,
                            "Wi-Fi activé",
                            Toast.LENGTH_SHORT
                    ).show();
                } else {
                    Toast.makeText(
                            MainActivity.this,
                            "Wi-Fi déjà activé",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }
        });
    }
}
